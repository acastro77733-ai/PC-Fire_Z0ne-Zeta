import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Message, GithubConfig, ToastType, ToastData, Attachment, EnvVar, FileNode, RuntimeMode } from './types';
import { streamGeminiResponse } from './services/geminiService';
import { GithubSettingsModal } from './components/GithubSettingsModal';
import { CodeBlock } from './components/CodeBlock';
import { TerminalPanel } from './components/TerminalPanel';
import { OutputPanel } from './components/OutputPanel';
import { DraggablePanel } from './components/DraggablePanel';
import { BridgePanel } from './components/BridgePanel';
import { FileSystemDirectoryHandle, getFileTree, readFileFromLocal } from './services/localFileSystem';
import { writeFileToVFS, runPythonScript, runPythonCode, createZipArchive, loadZipToVFS } from './services/pythonRuntime';
import { saveProjectSnapshot, getAllSnapshots, deleteSnapshot, ProjectSnapshot } from './services/projectStorage';
import { fetchRepoZip } from './services/githubService';
import { SPI_ENGINE_SCRIPT } from './services/spiTemplates';
import { 
  Bot, Send, Settings, Github, User, Sparkles, StopCircle, ChevronDown, ChevronRight, Paperclip, X, FileText, 
  Image as ImageIcon, Database, HardDrive, Folder, FileCode, RefreshCw, Play, Terminal as TerminalIcon, Code2, 
  Loader2, Monitor, Mic, ChevronsLeft, ChevronsRight, Zap, Brain, Rocket, Cpu, Download, ZoomIn, ZoomOut, Maximize, Globe, Link, Server, Archive, Cloud, Trash2, Clock, Save, Activity
} from 'lucide-react';

const parseMessageContent = (content: string) => {
  const regex = /```(\w+)?\n([\s\S]*?)```/g;
  const parts = [];
  let lastIndex = 0;
  let match;
  while ((match = regex.exec(content)) !== null) {
    if (match.index > lastIndex) parts.push({ type: 'text', content: content.slice(lastIndex, match.index) });
    parts.push({ type: 'code', language: match[1] || 'text', content: match[2] });
    lastIndex = regex.lastIndex;
  }
  if (lastIndex < content.length) parts.push({ type: 'text', content: content.slice(lastIndex) });
  return parts;
};

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      content: window.electron 
        ? "Hello! I'm PowerCoder-Z Desktop. I have full access to your local system via Electron."
        : "Hello! I'm PowerCoder-Z. I'm a hybrid AI assistant running in the browser.",
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<string>('gemini-2.5-flash');
  const [isThinkingEnabled, setIsThinkingEnabled] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  const [isTerminalOpen, setIsTerminalOpen] = useState(true);
  const [isScriptEditorOpen, setIsScriptEditorOpen] = useState(false);
  const [isOutputOpen, setIsOutputOpen] = useState(false);
  const [isBridgeOpen, setIsBridgeOpen] = useState(false); 
  const [viewingImage, setViewingImage] = useState<{ name: string, data: string, mimeType: string } | null>(null);
  const [imageZoom, setImageZoom] = useState(1);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [toasts, setToasts] = useState<ToastData[]>([]);

  const [scriptContent, setScriptContent] = useState('# Write Python code here\nprint("Hello from Scratchpad")\n');
  const [isRunningScript, setIsRunningScript] = useState(false);
  const [lastScriptError, setLastScriptError] = useState<string | null>(null);

  const [outputData, setOutputData] = useState<{ 
      text: string; isError: boolean; sourceCode?: string; language?: string; images?: { name: string, data: string, mimeType: string }[]; isNeuralEngine?: boolean;
  } | null>(null);
  
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [savedConfigs, setSavedConfigs] = useState<GithubConfig[]>(() => {
    try { return JSON.parse(localStorage.getItem('powercoder_configs') || '[]'); } catch(e) { return []; }
  });
  const [activeConfigId, setActiveConfigId] = useState<string | null>(() => localStorage.getItem('powercoder_active_id'));
  const [envVars, setEnvVars] = useState<EnvVar[]>(() => {
      try { return JSON.parse(localStorage.getItem('powercoder_env_vars') || '[]'); } catch(e) { return []; }
  });
  
  const [localDirHandle, setLocalDirHandle] = useState<FileSystemDirectoryHandle | null>(null);
  const [virtualFileMap, setVirtualFileMap] = useState<Map<string, File> | null>(null);
  const [fileTree, setFileTree] = useState<FileNode[]>([]);
  const [isTreeLoading, setIsTreeLoading] = useState(false);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());

  const [snapshots, setSnapshots] = useState<ProjectSnapshot[]>([]);
  const [isSavingSnapshot, setIsSavingSnapshot] = useState(false);
  const [isDownloadingRepo, setIsDownloadingRepo] = useState(false);

  useEffect(() => { refreshSnapshots(); }, []);
  useEffect(() => { if (!activeConfigId && savedConfigs.length > 0) setActiveConfigId(savedConfigs[0].id); }, [savedConfigs, activeConfigId]);
  useEffect(() => localStorage.setItem('powercoder_configs', JSON.stringify(savedConfigs)), [savedConfigs]);
  useEffect(() => localStorage.setItem('powercoder_env_vars', JSON.stringify(envVars)), [envVars]);
  useEffect(() => { if (activeConfigId) localStorage.setItem('powercoder_active_id', activeConfigId); else localStorage.removeItem('powercoder_active_id'); }, [activeConfigId]);
  useEffect(() => { setImageZoom(1); }, [viewingImage]);
  
  useEffect(() => { 
      if (localDirHandle) { setVirtualFileMap(null); refreshFileTree(); } 
      else if (!virtualFileMap) setFileTree([]);
  }, [localDirHandle]);

  const handleSetVirtualData = (data: { tree: FileNode[], map: Map<string, File> } | null) => {
      if (data) { setFileTree(data.tree); setVirtualFileMap(data.map); } 
      else { setVirtualFileMap(null); if (!localDirHandle) setFileTree([]); }
  };

  const refreshFileTree = async () => {
    if (!localDirHandle) return;
    setIsTreeLoading(true);
    try { const tree = await getFileTree(localDirHandle); setFileTree(tree); } 
    catch (e) { console.error("Failed to load tree", e); addToast("Failed to refresh file list", ToastType.ERROR); } 
    finally { setIsTreeLoading(false); }
  };

  const refreshSnapshots = async () => { try { const list = await getAllSnapshots(); setSnapshots(list); } catch (e) { console.error("Failed to load snapshots", e); } };
  const activeConfig = useMemo(() => savedConfigs.find(c => c.id === activeConfigId) || null, [savedConfigs, activeConfigId]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.onresult = (event: any) => {
            let finalTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
            }
            if (finalTranscript) setInput(prev => prev + (prev ? ' ' : '') + finalTranscript);
        };
        recognitionRef.current.onend = () => setIsListening(false);
        recognitionRef.current.onerror = (event: any) => { console.error("Speech Error", event.error); setIsListening(false); };
    }
  }, []);

  const toggleVoiceInput = () => {
      if (!recognitionRef.current) { addToast("Voice input not supported.", ToastType.ERROR); return; }
      if (isListening) { recognitionRef.current.stop(); setIsListening(false); } 
      else { recognitionRef.current.start(); setIsListening(true); }
  };

  const addToast = (message: string, type: ToastType) => {
    const id = Math.random().toString(36).substring(7);
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newAttachments: Attachment[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isImage = file.type.startsWith('image/');
      const isPDF = file.type === 'application/pdf';
      const isDocx = file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      const isTextFile = file.type.startsWith('text/') || ['.js','.py','.html','.json','.md','.txt','.ts','.tsx','.css','.csv'].some(ext => file.name.endsWith(ext));

      if (isImage || isPDF) {
        const base64 = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(file);
        });
        newAttachments.push({ id: Math.random().toString(36), type: 'file', mimeType: file.type, data: base64, name: file.name, isText: false });
      } else if (isDocx && window.mammoth) {
          try {
             const arrayBuffer = await file.arrayBuffer();
             const result = await window.mammoth.extractRawText({ arrayBuffer });
             newAttachments.push({ id: Math.random().toString(36), type: 'file', mimeType: 'text/plain', data: result.value, name: file.name, isText: true });
          } catch(e) { addToast(`Failed to parse DOCX: ${file.name}`, ToastType.ERROR); }
      } else if (isTextFile || isDocx) {
        const text = await file.text();
        newAttachments.push({ id: Math.random().toString(36), type: 'file', mimeType: file.type || 'text/plain', data: text, name: file.name, isText: true });
      }
    }
    setAttachments(prev => [...prev, ...newAttachments]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const fetchNodeContent = async (node: FileNode) => {
      if (localDirHandle) return await readFileFromLocal(localDirHandle, node.path);
      if (virtualFileMap) { const f = virtualFileMap.get(node.path); if(f) return { content: await f.text(), mimeType: f.type || 'text/plain' }; }
      return null;
  };

  const handleAttachLocalFile = async (node: FileNode) => {
      try {
          const result = await fetchNodeContent(node);
          if (!result) return;
          setAttachments(prev => [...prev, { id: Math.random().toString(36), type: 'file', mimeType: result.mimeType, data: result.content, name: node.name, isText: true }]);
          addToast(`Attached ${node.name}`, ToastType.SUCCESS);
      } catch (e: any) { addToast(`Error: ${e.message}`, ToastType.ERROR); }
  };

  const handleRunLocalFile = async (node: FileNode, e: React.MouseEvent) => {
      e.stopPropagation();
      if (!node.name.endsWith('.py')) return addToast("Only Python files executable", ToastType.INFO);
      if (!isTerminalOpen) setIsTerminalOpen(true);
      try {
          const result = await fetchNodeContent(node);
          if (result) { await writeFileToVFS(node.path, result.content); await runPythonScript(node.path, envVars); }
      } catch (e: any) { addToast(`Execution failed: ${e.message}`, ToastType.ERROR); }
  };

  const handleRunScript = async () => {
      if (!scriptContent.trim()) return;
      setIsRunningScript(true); setLastScriptError(null);
      if (!isTerminalOpen) setIsTerminalOpen(true);
      try {
          const result = await runPythonCode(scriptContent, envVars, 'browser');
          if (result) {
             setOutputData({ text: result.text || "Script executed", isError: false, sourceCode: scriptContent, language: 'python', images: result.images });
             if (result.images && result.images.length > 0) setIsOutputOpen(true);
             setIsOutputOpen(true); 
          }
      } catch (e: any) { setLastScriptError(e.message); addToast("Script error", ToastType.ERROR); } 
      finally { setIsRunningScript(false); }
  };

  const handleSpiderResult = (url: string, content: string) => {
      setIsBridgeOpen(false);
      const prompt = `I have crawled the website: ${url}\n\nHere is the content:\n\`\`\`\n${content}\n\`\`\`\n\nPlease analyze this data.`;
      handleSendMessage(prompt);
  };
  
  const handleZipDownload = async () => {
      if (!isTerminalOpen) setIsTerminalOpen(true);
      await createZipArchive('browser');
  };

  const handleDownloadRepo = async () => {
      if (!activeConfig) return;
      setIsDownloadingRepo(true);
      try {
          const result = await fetchRepoZip(activeConfig);
          if (result.success && result.data) {
              const blob = new Blob([result.data], { type: 'application/zip' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url; a.download = `${activeConfig.repo}-${activeConfig.branch}.zip`;
              document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
              addToast(`Downloaded ${activeConfig.repo}`, ToastType.SUCCESS);
          } else { throw new Error(result.message); }
      } catch (e: any) {
          const manualUrl = `https://github.com/${activeConfig.owner}/${activeConfig.repo}/archive/refs/heads/${activeConfig.branch}.zip`;
          if (confirm(`Download failed (${e.message}).\n\nClick OK to download manually from GitHub.`)) { window.open(manualUrl, '_blank'); }
      } finally { setIsDownloadingRepo(false); }
  };

  const handleSaveSnapshot = async () => {
      setIsSavingSnapshot(true);
      if (!isTerminalOpen) setIsTerminalOpen(true);
      try {
          const blob = await createZipArchive('browser', true);
          if (blob && blob instanceof Blob) {
              const name = prompt("Enter snapshot name:", `Project ${new Date().toLocaleTimeString()}`);
              if (name) { await saveProjectSnapshot(name, blob); await refreshSnapshots(); addToast("Snapshot saved to Library", ToastType.SUCCESS); }
          } else { addToast("Failed to create zip blob", ToastType.ERROR); }
      } catch (e: any) { addToast(e.message, ToastType.ERROR); } finally { setIsSavingSnapshot(false); }
  };

  const handleRestoreSnapshot = async (s: ProjectSnapshot) => {
      if (confirm(`Replace current workspace with "${s.name}"? Unsaved changes will be lost.`)) {
          if (!isTerminalOpen) setIsTerminalOpen(true);
          try { const buffer = await s.blob.arrayBuffer(); await loadZipToVFS(buffer); addToast(`Restored "${s.name}"`, ToastType.SUCCESS); } 
          catch(e) { addToast("Failed to restore", ToastType.ERROR); }
      }
  };

  const handleDeleteSnapshot = async (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      if (confirm("Delete this snapshot?")) { await deleteSnapshot(id); await refreshSnapshots(); }
  };

  const handleLoadSPI = async () => {
      addToast("Booting Neural Engine...", ToastType.INFO);
      setIsRunningScript(true);
      try {
          // Silent execution
          const result = await runPythonCode(SPI_ENGINE_SCRIPT, envVars, 'browser');
          // Update Output panel with a special flag
          setOutputData({ 
              text: result.text, 
              isError: false, 
              sourceCode: SPI_ENGINE_SCRIPT, 
              language: 'python', 
              images: result.images,
              isNeuralEngine: true // Flag to trigger custom UI in OutputPanel
          });
          setIsOutputOpen(true);
          addToast("Neural Engine Online", ToastType.SUCCESS);
      } catch (e: any) {
          addToast("Neural Engine Failed: " + e.message, ToastType.ERROR);
          setOutputData({ text: e.message, isError: true });
          setIsOutputOpen(true);
      } finally {
          setIsRunningScript(false);
      }
  };

  const handleSendMessage = async (manualContent?: string) => {
    const contentToSend = manualContent || input;
    if ((!contentToSend.trim() && attachments.length === 0) || isLoading) return;
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: contentToSend, timestamp: Date.now(), attachments: manualContent ? [] : [...attachments] };
    setMessages(prev => [...prev, userMsg]);
    if (!manualContent) { setInput(''); setAttachments([]); }
    setIsLoading(true);
    try {
      const modelMsgId = (Date.now() + 1).toString();
      setMessages(prev => [...prev, { id: modelMsgId, role: 'model', content: '', timestamp: Date.now(), isStreaming: true }]);
      const result = await streamGeminiResponse(messages, userMsg.content, userMsg.attachments || [], selectedModel, isThinkingEnabled ? 16384 : 0);
      let fullText = '';
      for await (const chunk of result) {
        fullText += chunk.text || '';
        setMessages(prev => prev.map(msg => msg.id === modelMsgId ? { ...msg, content: fullText } : msg));
      }
      setMessages(prev => prev.map(msg => msg.id === modelMsgId ? { ...msg, isStreaming: false } : msg));
      if (localDirHandle) refreshFileTree();
    } catch (error) {
      addToast("Failed to generate response.", ToastType.ERROR);
      setMessages(prev => prev.map(msg => msg.isStreaming ? { ...msg, content: msg.content + "\n[Error]", isStreaming: false } : msg));
    } finally { setIsLoading(false); }
  };

  const handleFixError = (code: string, errorMsg: string, language: string = 'python') => {
      handleSendMessage(`I ran this ${language} code and got an error:\n\`\`\`${language}\n${code}\n\`\`\`\nError: ${errorMsg}\n\nPlease fix it.`);
  };

  return (
    <div className="flex h-screen bg-gray-900 text-gray-100 font-sans overflow-hidden select-none">
       {/* Background */}
       <div className="absolute inset-0 z-0 pointer-events-none opacity-50 bg-repeat" style={{ backgroundImage: "url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iIzFCMUUyMyIgZD0iTTAgMGgxMHYxMEgwVjB6bTEwIDEwaDEwdjEwSDEwVjEweiIvPjwvc3ZnPg==')" }}></div>
      
      <aside className={`${isSidebarCollapsed ? 'w-16' : 'w-80'} bg-gray-900 border-r border-gray-800 flex flex-col hidden md:flex shrink-0 transition-all duration-300 ease-in-out relative z-30`}>
        <div className="p-4 border-b border-gray-800 flex items-center gap-3 shrink-0 justify-between app-drag-region">
           <div className="flex items-center gap-3">
             <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shrink-0 shadow-lg">
               <Bot className="text-white w-5 h-5" />
             </div>
             {!isSidebarCollapsed && (
               <div>
                 <h1 className="font-bold text-lg bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400 whitespace-nowrap">PowerCoder-Z</h1>
                 {window.electron && <span className="text-[9px] text-green-400 font-mono uppercase tracking-wider">Desktop Pro</span>}
               </div>
             )}
           </div>
           <button onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)} className="text-gray-500 hover:text-white"><ChevronsRight className={`w-4 h-4 transition-transform ${!isSidebarCollapsed ? 'rotate-180' : ''}`}/></button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-6">
            {/* Project Snapshots Section */}
            <div className="space-y-2">
                 {!isSidebarCollapsed && <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider"><div className="flex items-center gap-2"><Cloud className="w-3 h-3" /><span>Project Snapshots</span></div><button onClick={handleSaveSnapshot} disabled={isSavingSnapshot} title="Save Current State"><Save className={`w-3 h-3 ${isSavingSnapshot ? 'animate-pulse' : ''}`} /></button></div>}
                 {!isSidebarCollapsed ? (
                     <div className="bg-gray-900/50 border border-gray-800 rounded-lg min-h-[60px] max-h-[150px] overflow-y-auto p-2 space-y-1">
                         {snapshots.length === 0 && <div className="text-gray-600 text-[10px] italic text-center">No saved snapshots</div>}
                         {snapshots.map(s => (
                             <div key={s.id} onClick={() => handleRestoreSnapshot(s)} className="flex items-center justify-between p-2 rounded hover:bg-gray-800 cursor-pointer group">
                                 <div className="flex items-center gap-2 min-w-0">
                                     <Clock className="w-3 h-3 text-blue-400" />
                                     <div className="truncate">
                                         <div className="text-xs text-gray-300 truncate">{s.name}</div>
                                         <div className="text-[10px] text-gray-500">{(s.size / 1024).toFixed(1)}KB</div>
                                     </div>
                                 </div>
                                 <button onClick={(e) => handleDeleteSnapshot(s.id, e)} className="text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100"><Trash2 className="w-3 h-3"/></button>
                             </div>
                         ))}
                     </div>
                 ) : (
                     <button onClick={() => setIsSidebarCollapsed(false)} className="w-full flex justify-center p-2 hover:bg-gray-800 rounded"><Cloud className="w-5 h-5 text-gray-400"/></button>
                 )}
            </div>

            {/* File Explorer Section */}
            <div className="space-y-2">
                {!isSidebarCollapsed && <div className="flex items-center justify-between text-xs font-semibold text-gray-500 uppercase tracking-wider"><div className="flex items-center gap-2"><HardDrive className="w-3 h-3" /><span>Files</span></div><div className="flex gap-1">{localDirHandle && <button onClick={refreshFileTree} title="Refresh"><RefreshCw className={`w-3 h-3 ${isTreeLoading ? 'animate-spin' : ''}`} /></button>}<button onClick={handleZipDownload} title="Download Zip"><Archive className="w-3 h-3" /></button></div></div>}
                {(localDirHandle || virtualFileMap) ? (
                    <div className={`bg-gray-900/50 border border-gray-800 rounded-lg min-h-[100px] text-sm font-mono ${isSidebarCollapsed ? 'p-1' : 'p-2'}`}>{fileTree.length > 0 ? (fileTree.map((node) => <div key={node.path} style={{ paddingLeft: 0 }}>{node.kind === 'directory' ? <div className="flex items-center gap-1.5 py-1 text-gray-400 hover:text-white cursor-pointer select-none" onClick={() => { const next = new Set(expandedFolders); if (next.has(node.path